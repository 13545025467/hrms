CREATE PROCEDURE upSal
  AS
  psal EMPLOYEE.sal%TYPE ;
  pempno EMPLOYEE.empno%TYPE ;
  BEGIN
    SELECT SAL,EMPNO INTO psal,pempno  from EMPLOYEE where pempno=7369;

    UPDATE EMPLOYEE SET SAL=SAL+1000 where pempno=7369;
  END;
/
