CREATE TRIGGER TG_A
BEFORE INSERT
  ON T_USER
FOR EACH ROW
  DECLARE
    BEGIN
      IF :NEW.U_NAME LIKE 'a%' THEN
      raise_application_error('-20003','不能插入以a开头的名字');
      END IF ;
  END;
/
